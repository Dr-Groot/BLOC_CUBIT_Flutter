import 'package:dota_bloc/cubit/hero_cubit.dart';
import 'package:dota_bloc/hero_network.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'hero_view.dart';

void main() {
  runApp(DotaApp());
}

class DotaApp extends StatefulWidget {
  const DotaApp({Key? key}) : super(key: key);

  @override
  State<DotaApp> createState() => _DotaAppState();
}

class _DotaAppState extends State<DotaApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: BlocProvider<HeroCubit>(
        create: (BuildContext context) => HeroCubit(HeroNetwork()),
          child: HeroView()
      ),
    );
  }
}
