class HeroModel {
  String? name;
  String? localisedName;

  HeroModel({this.name, this.localisedName});

  factory HeroModel.fromJson(Map<String, dynamic> json) => HeroModel(
    name: json['name'],
    localisedName: json['localized_name']
  );

}