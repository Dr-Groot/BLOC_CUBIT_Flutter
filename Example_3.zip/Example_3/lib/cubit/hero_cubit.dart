import 'package:dota_bloc/hero_model.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../hero_network.dart';
import 'hero_state.dart';

class HeroCubit extends Cubit<HeroState> {
  final HeroNetwork _heroNetwork;

  HeroCubit(this._heroNetwork) : super(HeroLoadingState()) {
    fetchHeroList();
  }

  void fetchHeroList() async {
    emit(HeroLoadingState());
    try {
      final heros = await _heroNetwork.getHeroData();
      emit(HeroLoadedState(heros));
    } catch (e) {
      emit(HeroErrorState());
    }
  }

  void fetchOneName() {
    emit(HeroDemoState([HeroModel(name: 'Big', localisedName: 'Bee')]));
  }

}