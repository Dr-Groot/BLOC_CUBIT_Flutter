import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:dota_bloc/hero_model.dart';

@immutable
abstract class HeroState extends Equatable  {}

class HeroLoadingState extends HeroState {

  @override
  List<Object?> get props => [];
}

class HeroLoadedState extends HeroState {
  final List<HeroModel> heros;

  HeroLoadedState(this.heros);

  @override
  List<Object?> get props => [heros];
}

class HeroErrorState extends HeroState {

  @override
  List<Object?> get props => [];
}

class HeroDemoState extends HeroState {
  final List<HeroModel> heros;

  HeroDemoState(this.heros);

  @override
  List<Object?> get props => [heros];

}