import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'hero_model.dart';

class HeroNetwork {

  final baseUrl = 'https://api.opendota.com/api/heroStats';

  Future<List<HeroModel>> getHeroData() async {
    final response = await Dio().get(baseUrl);
    List<HeroModel> heroData = [];

    if (response.statusCode == 200) {
      try {
        response.data.forEach((element) {
          heroData.add(HeroModel.fromJson(element));
        });
      } catch (error) {
        debugPrint('Api Error: $error');
      }
      return heroData;
    } else {
      throw Exception(response);
    }
  }

}