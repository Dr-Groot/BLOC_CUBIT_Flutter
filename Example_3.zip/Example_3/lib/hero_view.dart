import 'package:dota_bloc/cubit/hero_cubit.dart';
import 'package:dota_bloc/cubit/hero_state.dart';
import 'package:dota_bloc/hero_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class HeroView extends StatelessWidget {
  const HeroView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text('Dota Heros'),
        backgroundColor: Colors.teal,
      ),
      body: BlocBuilder<HeroCubit, HeroState>(
        builder: (context, state) {

          if (state is HeroLoadingState) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          if (state is HeroLoadedState) {
           List<HeroModel> heroList = state.heros;
           heroList.forEach((element) {
             if (element.localisedName == 'Axe') {
               debugPrint('AXE FOUND');
             }
           });
           // context.read<HeroCubit>().fetchOneName();
           return ListView.builder(
               itemCount: heroList.length,
               itemBuilder: (_, index) {
                 return Card(
                   color: Colors.black,
                   child: ListTile(
                     title: Text(
                       '${heroList[index].localisedName}',
                       style:
                       const TextStyle(color: Colors.white, fontSize: 17.0),
                     ),
                     subtitle: Text(
                       '${heroList[index].name}',
                       style: const TextStyle(color: Colors.red),
                     ),
                   ),
                 );
               });
          }

          if (state is HeroErrorState) {
            return Center(
              child: Container(
                child: const Text('Error')
              ),
            );
          }

          if (state is HeroDemoState) {
            List<HeroModel> demoList = state.heros;
            return Center(
              child: Container(
                child: Text('${demoList[0].name}', style: TextStyle(color: Colors.white),),
              ),
            );
          }

          return Container();
        },
      ),
    );
  }
}
