package com.example.dota_bloc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
