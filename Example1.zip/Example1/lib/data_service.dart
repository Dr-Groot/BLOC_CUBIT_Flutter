import 'dart:convert';
import 'package:dio/dio.dart';
import 'post.dart';

class DataService {
  final baseUrl = 'https://jsonplaceholder.typicode.com/posts';

  Future<List<Post>> getPost() async {
    try {
      List<Post> postData = [];

      final response = await Dio().get(baseUrl);
      response.data.forEach((element) {
        postData.add(Post.fromJson(element));
      });

      return postData;

    } catch (e) {
      throw e;
    }
  }
}